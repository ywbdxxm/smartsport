"""
ESP32 完整硬件检测脚本
兼容 MicroPython v1.19+，适配大多数编译版本。
功能：Flash 总容量、FAT 分区空间、PSRAM 检测、GC 堆/系统堆、
      最大连续内存块、可选 Flash 写入测试。
"""

import os, gc, sys, micropython

# ---------- 格式化工具 ----------
def fmt(b):
    """字节数转可读字符串"""
    if b >= 1024 * 1024:
        return f"{b / 1048576:.2f} MB"
    elif b >= 1024:
        return f"{b / 1024:.2f} KB"
    return f"{b} B"

# ---------- 平台兼容导入 ----------
HAS_ESP  = False
HAS_ESP32 = False
try:
    import esp
    HAS_ESP = True
except ImportError:
    pass

try:
    import esp32
    HAS_ESP32 = True
except ImportError:
    pass

if not HAS_ESP and not HAS_ESP32:
    print("未检测到 ESP 平台模块，部分功能不可用。")

# ---------- Flash 总容量（多级回退） ----------
def get_flash_total():
    """返回 Flash 总容量字节数，失败返回 0"""
    # 方法1：esp.flash_size()（最可靠，优先使用）
    if HAS_ESP:
        try:
            if hasattr(esp, "flash_size"):
                return esp.flash_size()
        except:
            pass
    # 方法2：esp32.flash_size()（官方常用）
    if HAS_ESP32:
        try:
            if hasattr(esp32, "flash_size"):
                return esp32.flash_size()
        except:
            pass
    # 方法3：machine.flash_size()（少数移植版）
    try:
        import machine
        if hasattr(machine, "flash_size"):
            return machine.flash_size()
    except:
        pass
    # 方法4：分区表累加（近似值，可能小于真实值）
    if HAS_ESP32 and hasattr(esp32, "Partition"):
        try:
            total = 0
            for p in esp32.Partition.find():
                total += p.size
            if total > 0:
                return total  # 所有分区大小之和
        except:
            pass
    return 0

# ---------- PSRAM 信息（多级回退） ----------
def get_psram_info():
    """返回 (存在标志, 大小字节, 检测方法描述)"""
    # --- 方法1：通过 esp / esp32 API 直接查询 ---
    try:
        import esp
        if hasattr(esp, "psram") and esp.psram():
            size = esp.psram_size() if hasattr(esp, "psram_size") else 0
            if size > 0:
                return True, size, "esp.psram() API"
    except:
        pass

    try:
        import esp32
        from esp32 import HEAP_SPIRAM
        total = esp32.heap_caps_get_total_size(HEAP_SPIRAM)
        if total > 0:
            return True, total, "esp32.heap_caps (SPIRAM)"
    except:
        pass

    # --- 方法2：通过 GC 堆总量推断 ---
    gc.collect()
    gc_total = gc.mem_alloc() + gc.mem_free()
    # ESP32 内部 DRAM 一般给 GC 的部分大约 64~128 KB
    # 如果 GC 总堆 > 512 KB，说明肯定合并了 PSRAM
    if gc_total > 512 * 1024:
        # 尝试精确测量：分配一个刚好超过内部 DRAM 的大 buffer
        # 如果成功，说明 PSRAM 可用
        try:
            test_buf = bytearray(700 * 1024)  # 700 KB
            del test_buf
            gc.collect()
            # 第二次分配 1 MB 进一步确认
            test_buf2 = bytearray(1024 * 1024)
            del test_buf2
            gc.collect()
            return True, gc_total, "GC堆总量推断 (>512 KB 且分配成功)"
        except MemoryError:
            pass

    # --- 都失败，认为无 PSRAM ---
    return False, 0, "未检测到"

# ---------- 最大连续可分配内存 ----------
def max_allocatable():
    """实测当前可分配的最大连续 bytearray 字节数"""
    gc.collect()
    # 快速上探
    upper = 64
    while True:
        try:
            _ = bytearray(upper)
            del _
            gc.collect()
            upper *= 2
            if upper > 16 * 1024 * 1024:   # 16 MB 上限
                upper = 16 * 1024 * 1024
                break
        except MemoryError:
            break
    # 二分精确定位
    low, high = 64, upper
    last_ok = 0
    while low <= high:
        mid = (low + high) // 2
        try:
            _ = bytearray(mid)
            del _
            gc.collect()
            last_ok = mid
            low = mid + 1
        except MemoryError:
            high = mid - 1
    return last_ok

# ---------- 主报告 ----------
def print_report(do_flash_write_test=False):
    print("=" * 60)
    print("        ESP32 完整硬件资源报告")
    print("=" * 60)

    # 1. Flash 总容量
    flash_total = get_flash_total()
    print(f"\n[Flash 总容量] ", end="")
    if flash_total > 0:
        print(f"{fmt(flash_total)}")
    else:
        print("无法获取")

    # 2. FAT 文件系统
    print("\n[文件系统 (FAT)]")
    try:
        st = os.statvfs("/")
        block_size = st[0]
        total_blocks = st[2]
        free_blocks = st[3]
        fat_total = block_size * total_blocks
        fat_free = block_size * free_blocks
        print(f"  总空间: {fmt(fat_total)}")
        print(f"  已用:   {fmt(fat_total - fat_free)}")
        print(f"  可用:   {fmt(fat_free)}")
        # 辅助判断：如果 FAT 分区 > 12MB，则 Flash 大概率是 16MB
        if flash_total == 0 and fat_total > 12 * 1024 * 1024:
            print("  (推测总 Flash 为 16 MB)")
    except Exception as e:
        print(f"  无法获取: {e}")

    # 3. 可选的 Flash 写入测试
    if do_flash_write_test:
        print("\n[Flash 写入测试 (1 MB)]")
        try:
            with open("_test.bin", "wb") as f:
                f.write(b"\x00" * (1024 * 1024))
            print("  写入 1 MB 成功")
            os.remove("_test.bin")
        except Exception as e:
            print(f"  写入失败: {e}")

    # 4. PSRAM 检测
    print("\n[PSRAM 状态]")
    has_psram, psram_size, method = get_psram_info()
    print(f"  存在: {'是' if has_psram else '否'}")
    if has_psram:
        print(f"  大小: {fmt(psram_size)}")
        print(f"  检测方法: {method}")
    else:
        print(f"  检测方法: {method}")

    # 5. GC 堆 & 系统堆
    print("\n[内存堆]")
    gc.collect()
    gc_used = gc.mem_alloc()
    gc_free = gc.mem_free()
    gc_total = gc_used + gc_free
    print(f"  GC 堆总量: {fmt(gc_total)}")
    print(f"  GC 已用:   {fmt(gc_used)}")
    print(f"  GC 空闲:   {fmt(gc_free)}")
    print(f"  GC 碎片:   内部小池情况见下方 mem_info")

    # micropython.mem_info(1) 打印详细块信息
    print("\n[系统堆详细] micropython.mem_info(1):")
    micropython.mem_info(1)

    # 6. 最大连续内存块实测
    print("\n[最大连续分配测试]")
    max_blk = max_allocatable()
    print(f"  最大连续可分配: {fmt(max_blk)}")
    # 如果 GC 总量接近 PSRAM 大小，说明 PSRAM 已并入 GC
    if has_psram and psram_size > 0 and abs(gc_total - psram_size) < 2 * 1024 * 1024:
        print("  (PSRAM 已合并到 GC 堆中)")

    # 7. ESP32 内部 DRAM 细节（如果可用）
    if HAS_ESP32:
        try:
            from esp32 import HEAP_DATA
            dram_total = esp32.heap_caps_get_total_size(HEAP_DATA)
            dram_free = esp32.heap_caps_get_free_size(HEAP_DATA)
            print(f"\n[内部 DRAM] 总量: {fmt(dram_total)}, 空闲: {fmt(dram_free)}")
        except:
            pass

    print("\n" + "=" * 60)
    print("报告结束")

# ---------- 执行入口 ----------
if __name__ == "__main__":
    # 默认不进行 Flash 写入测试（避免损耗）。如果需要，改为 True
    print_report(do_flash_write_test=False)